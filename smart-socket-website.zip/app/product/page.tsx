import Image from 'next/image'

export default function Product() {
  return (
    <div className="space-y-8">
      <h2 className="text-4xl font-bold mb-6">02. PRODUCT</h2>
      <div className="grid md:grid-cols-2 gap-8">
        <div className="bg-blue-100 p-6 rounded-lg">
          <h3 className="text-2xl font-semibold mb-4">Les Avantages</h3>
          <Image src="/placeholder.svg" alt="Avantages" width={300} height={200} className="mb-4 rounded-lg" />
          <p>
            Smart Socket ne se contente pas de vous faire économiser de l'argent, elle contribue aussi à réduire votre empreinte carbone. Contrairement à d'autres solutions sur le marché, elle est intuitive, accessible et s'adapte à vos besoins grâce à son intelligence artificielle.
          </p>
        </div>
        <div className="bg-purple-100 p-6 rounded-lg">
          <h3 className="text-2xl font-semibold mb-4">MARCHÉ ET OPPORTUNITÉ</h3>
          <Image src="/placeholder.svg" alt="Marché" width={300} height={200} className="mb-4 rounded-lg" />
          <p>
            Le marché des objets connectés est en plein essor. Smart Socket répond à un besoin croissant de simplicité et d'efficacité énergétique, tant pour les particuliers que pour les entreprises.
          </p>
        </div>
      </div>
      <div className="grid md:grid-cols-2 gap-8">
        <div className="bg-yellow-100 p-6 rounded-lg">
          <h3 className="text-2xl font-semibold mb-4">FAISABILITÉ</h3>
          <ul className="list-disc list-inside space-y-2">
            <li>Concept valide : La prise intelligente répond à un besoin réel avec des avantages concrets.</li>
            <li>Technologie disponible : Les technologies pour son développement sont accessibles et fiables.</li>
            <li>Potentiel commercial : Le marché des solutions intelligentes de gestion de l'énergie est important et en croissance.</li>
          </ul>
        </div>
        <div className="bg-green-100 p-6 rounded-lg">
          <h3 className="text-2xl font-semibold mb-4">PUBLIC CIBLE</h3>
          <ul className="list-disc list-inside space-y-2">
            <li>Particuliers : Propriétaires et locataires souhaitant réduire leurs factures d'électricité.</li>
            <li>Petites entreprises : Gestionnaires de bureaux cherchant à optimiser leur consommation énergétique.</li>
            <li>Institutions éducatives et publiques : Sensibilisation et réduction des dépenses énergétiques.</li>
          </ul>
        </div>
      </div>
    </div>
  )
}

