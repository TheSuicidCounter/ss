export default function TargetAudience() {
  return (
    <div>
      <h2 className="text-3xl font-bold mb-4">PUBLIC CIBLE</h2>
      <ul className="list-disc list-inside">
        <li>Particuliers : Propriétaires et locataires souhaitant réduire leurs factures d'électricité.</li>
        <li>Petites entreprises : Gestionnaires de bureaux cherchant à optimiser leur consommation énergétique.</li>
        <li>Institutions éducatives et publiques : Sensibilisation et réduction des dépenses énergétiques.</li>
      </ul>
    </div>
  )
}

