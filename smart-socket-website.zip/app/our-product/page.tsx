export default function OurProduct() {
  return (
    <div>
      <h2 className="text-3xl font-bold mb-4">OUR PRODUCT</h2>
      <div className="grid md:grid-cols-2 gap-8">
        <div>
          <h3 className="text-2xl font-semibold mb-2">Website</h3>
          <ul className="list-disc list-inside">
            <li>Tableau de bord pour suivre la consommation et repérer les appareils énergivores.</li>
            <li>Conseils personnalisés pour réduire les dépenses énergétiques.</li>
            <li>Espace client pour gérer paramètres et abonnements.</li>
          </ul>
        </div>
        <div>
          <h3 className="text-2xl font-semibold mb-2">Application Mobile</h3>
          <ul className="list-disc list-inside">
            <li>Contrôle à distance des appareils.</li>
            <li>Programmation pour optimiser l'utilisation.</li>
            <li>Alertes en cas de surcharge.</li>
          </ul>
        </div>
      </div>
    </div>
  )
}

