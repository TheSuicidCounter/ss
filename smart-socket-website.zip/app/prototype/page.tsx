import Image from 'next/image'

export default function Prototype() {
  return (
    <div className="space-y-8">
      <h2 className="text-4xl font-bold mb-6">04. ETAT D'AVANCEMENT DU PROTOTYPE</h2>
      <div className="grid md:grid-cols-3 gap-8">
        <div className="bg-blue-100 p-6 rounded-lg">
          <h3 className="text-2xl font-semibold mb-4">Phase de Prototypage</h3>
          <Image src="/placeholder.svg" alt="Prototypage" width={200} height={150} className="mb-4 rounded-lg" />
          <p>La phase de prototype est en cours. Nous sommes actuellement en plein développement.</p>
        </div>
        <div className="bg-green-100 p-6 rounded-lg">
          <h3 className="text-2xl font-semibold mb-4">Préparation a la Production</h3>
          <Image src="/placeholder.svg" alt="Production" width={200} height={150} className="mb-4 rounded-lg" />
          <p>Nous sommes en phase de préparation à la production à grande échelle, en collaboration avec des partenaires de fabrication.</p>
        </div>
        <div className="bg-yellow-100 p-6 rounded-lg">
          <h3 className="text-2xl font-semibold mb-4">Optimisation du Design</h3>
          <Image src="/placeholder.svg" alt="Design" width={200} height={150} className="mb-4 rounded-lg" />
          <p>Des améliorations sont apportées au design et à l'ergonomie du prototype, en tenant compte des commentaires des utilisateurs.</p>
        </div>
      </div>
    </div>
  )
}

