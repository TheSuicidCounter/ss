import Image from 'next/image'

export default function ProblemSolution() {
  return (
    <div className="space-y-8">
      <h2 className="text-4xl font-bold mb-6">01. PROBLEM VS SOLUTION</h2>
      <div className="grid md:grid-cols-2 gap-8">
        <div className="bg-red-100 p-6 rounded-lg">
          <h3 className="text-2xl font-semibold mb-4">PROBLEM</h3>
          <Image src="/placeholder.svg" alt="Problem" width={300} height={200} className="mb-4 rounded-lg" />
          <p>
            Chaque année, des millions de foyers gaspillent de l'électricité à cause des appareils laissés en veille ou inutilisés. Résultat : des factures élevées et un impact écologique énorme. De plus, les risques de surchauffe et de surcharge électrique posent de réels dangers pour la sécurité des habitations.
          </p>
        </div>
        <div className="bg-green-100 p-6 rounded-lg">
          <h3 className="text-2xl font-semibold mb-4">SOLUTION</h3>
          <Image src="/placeholder.svg" alt="Solution" width={300} height={200} className="mb-4 rounded-lg" />
          <p>Voici Smart Socket, une solution innovante qui :</p>
          <ul className="list-disc list-inside mt-2 space-y-2">
            <li>Mesure la consommation énergétique en temps réel.</li>
            <li>Coupe l'alimentation des appareils inutilisés pour éviter le gaspillage.</li>
            <li>Se contrôle à distance via une application mobile.</li>
            <li>Détecte les surcharges pour prévenir les accidents.</li>
          </ul>
          <p className="mt-4">
            Facile à utiliser et abordable, Smart Socket permet d'économiser jusqu'à 20 % sur les factures d'électricité.
          </p>
        </div>
      </div>
    </div>
  )
}

