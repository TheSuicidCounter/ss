import Image from 'next/image'

export default function Home() {
  return (
    <div className="space-y-8">
      <h2 className="text-6xl font-bold text-center">HELLO!</h2>
      <div className="bg-yellow-100 p-6 rounded-lg">
        <h3 className="text-2xl font-semibold mb-4">hhhhhhhhhhhh</h3>
        <div className="flex items-center space-x-4">
          <Image src="/placeholder.svg" alt="Introduction" width={200} height={200} className="rounded-lg" />
          <p className="text-lg">
            gjosudghfboauidhfiopyugsdoiyufagodiyhjufgbasopuikdhjfgopasuidfgayuishdf.
          </p>
        </div>
      </div>
    </div>
  )
}

