import './globals.css'
import { Inter } from 'next/font/google'
import Link from 'next/link'

const inter = Inter({ subsets: ['latin'] })

export const metadata = {
  title: 'Smart Socket',
  description: 'Transforming your energy consumption',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={`${inter.className} bg-gray-100`}>
        <header className="bg-blue-600 text-white p-6">
          <h1 className="text-4xl font-bold text-center">Smart Socket</h1>
        </header>
        <nav className="bg-gray-200 p-4">
          <h2 className="text-2xl font-semibold mb-2">TABLE OF CONTENT</h2>
          <ol className="list-decimal list-inside">
            <li><Link href="/problem-solution" className="hover:underline">PROBLEM VS SOLUTION</Link></li>
            <li><Link href="/product" className="hover:underline">PRODUCT</Link></li>
            <li><Link href="/technologies" className="hover:underline">TECHNOLOGIES UTILISÉES</Link></li>
            <li><Link href="/prototype" className="hover:underline">ETAT D'AVANCEMENT DU PROTOTYPE</Link></li>
          </ol>
        </nav>
        <main className="container mx-auto p-6">
          {children}
        </main>
        <footer className="bg-blue-600 text-white p-8 text-center">
          <p className="text-2xl font-bold">"JUST KEEP MOVING FORWARD."</p>
        </footer>
      </body>
    </html>
  )
}

