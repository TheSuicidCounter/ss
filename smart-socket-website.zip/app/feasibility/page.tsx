export default function Feasibility() {
  return (
    <div>
      <h2 className="text-3xl font-bold mb-4">FAISABILITÉ</h2>
      <ul className="list-disc list-inside">
        <li>Concept valide : La prise intelligente répond à un besoin réel avec des avantages concrets.</li>
        <li>Technologie disponible : Les technologies pour son développement sont accessibles et fiables.</li>
        <li>Potentiel commercial : Le marché des solutions intelligentes de gestion de l'énergie est important et en croissance.</li>
      </ul>
    </div>
  )
}

