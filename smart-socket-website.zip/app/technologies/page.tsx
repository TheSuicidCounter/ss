import Image from 'next/image'

export default function Technologies() {
  return (
    <div className="space-y-8">
      <h2 className="text-4xl font-bold mb-6">03. TECHNOLOGIES UTILISÉES</h2>
      <div className="grid md:grid-cols-2 gap-8">
        <div className="bg-blue-100 p-6 rounded-lg">
          <h3 className="text-2xl font-semibold mb-4">IoT</h3>
          <Image src="/placeholder.svg" alt="IoT" width={300} height={200} className="mb-4 rounded-lg" />
          <p>Capteurs de courant, de tension et de température pour la collecte de données</p>
        </div>
        <div className="bg-green-100 p-6 rounded-lg">
          <h3 className="text-2xl font-semibold mb-4">Intelligence artificielle</h3>
          <Image src="/placeholder.svg" alt="AI" width={300} height={200} className="mb-4 rounded-lg" />
          <p>Algorithmes pour analyser les données et fournir des recommandations personnalisées.</p>
        </div>
      </div>
      <div className="grid md:grid-cols-2 gap-8">
        <div className="bg-yellow-100 p-6 rounded-lg">
          <h3 className="text-2xl font-semibold mb-4">Website</h3>
          <ul className="list-disc list-inside space-y-2">
            <li>Tableau de bord pour suivre la consommation et repérer les appareils énergivores.</li>
            <li>Conseils personnalisés pour réduire les dépenses énergétiques.</li>
            <li>Espace client pour gérer paramètres et abonnements.</li>
          </ul>
        </div>
        <div className="bg-purple-100 p-6 rounded-lg">
          <h3 className="text-2xl font-semibold mb-4">Application Mobile</h3>
          <ul className="list-disc list-inside space-y-2">
            <li>Contrôle à distance des appareils.</li>
            <li>Programmation pour optimiser l'utilisation.</li>
            <li>Alertes en cas de surcharge.</li>
          </ul>
        </div>
      </div>
    </div>
  )
}

